import os
import ast
import pytest
from frontend.lexer import lex, Token
from frontend.parser import parse, BinOp, Var, Num

def test_lexer():
    tokens = lex("a = 1 + 2.5 * 3")
    types = [t.type for t in tokens]
    assert types == ['ID', 'ASSIGN', 'NUM', 'PLUS', 'NUM', 'MUL', 'NUM', 'EOF']

def test_parser_precedence():
    # 1 + 2 * 3 should be 1 + (2 * 3)
    node = parse("1 + 2 * 3")
    assert isinstance(node, BinOp)
    assert node.op == '+'
    assert isinstance(node.right, BinOp)
    assert node.right.op == '*'

def test_parser_associativity():
    # 2 ^ 3 ^ 4 should be 2 ^ (3 ^ 4)
    node = parse("2 ^ 3 ^ 4")
    assert isinstance(node, BinOp)
    assert node.op == '^'
    assert isinstance(node.left, Num)
    assert node.left.value == 2.0
    assert isinstance(node.right, BinOp)
    assert node.right.op == '^'

def test_test_expression_compiles():
    from compiler import compile_expression
    expr = "finalValue = ((principal * rate * time) / 100) + (principal * (1 + rate/100)^time) - fees"
    res = compile_expression(expr)
    assert res.ast is not None
    assert len(res.tac) > 0

def test_constant_folding():
    from compiler import compile_expression
    res = compile_expression("result = 2 + 3 * 4")
    # 2 + 3 * 4 -> 14
    assert len(res.opt_quads) == 1
    assert res.opt_quads[0].op == '='
    assert res.opt_quads[0].arg1 == '14'

def test_cse():
    from compiler import compile_expression
    res = compile_expression("result = (a * b) + (a * b)")
    # Should use the same temp rather than compute a*b twice.
    # Without CSE: t1 = a*b, t2=a*b, t3=t1+t2. (3 insts + result) = 4
    # With CSE: t1 = a*b, t2=t1+t1. t2 copy prop? result = t1+t1. (2 inst)
    assert len(res.opt_quads) < len(res.quads)

def test_cascading_dead_code():
    from compiler import compile_expression
    # (a+b) - (a+b) + c
    # CSE handles a+b -> t1 - t1 -> 0
    # Alg Simp -> 0 + c -> c
    res = compile_expression("result = (a + b) - (a + b) + c")
    assert len(res.opt_quads) == 1
    assert res.opt_quads[0].arg1 == 'c'

def test_architecture_boundary():
    # Enforce programmatically that NO python file in frontend/ imports from backend/
    frontend_dir = os.path.join(os.path.dirname(__file__), 'frontend')
    
    for filename in os.listdir(frontend_dir):
        if not filename.endswith('.py'):
            continue
        
        filepath = os.path.join(frontend_dir, filename)
        with open(filepath, 'r', encoding='utf-8') as f:
            source = f.read()
            
        tree = ast.parse(source, filename=filepath)
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    assert not alias.name.startswith('backend'), f"Architecture violation in {filename}: imports backend"
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    assert not node.module.startswith('backend'), f"Architecture violation in {filename}: imports backend"
