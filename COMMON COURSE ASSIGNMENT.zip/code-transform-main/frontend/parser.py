from dataclasses import dataclass
from typing import List, Optional
from frontend.lexer import Token, lex

@dataclass
class Node:
    pass

@dataclass
class Num(Node):
    value: float

@dataclass
class Var(Node):
    name: str

@dataclass
class BinOp(Node):
    op: str
    left: Node
    right: Node

@dataclass
class UnaryOp(Node):
    op: str
    operand: Node

@dataclass
class Assign(Node):
    target: str
    value: Node

def ast_to_text(node: Node, indent: int = 0) -> str:
    pad = "  " * indent
    if isinstance(node, Num):
        return f"{pad}Num({node.value})"
    elif isinstance(node, Var):
        return f"{pad}Var({node.name})"
    elif isinstance(node, BinOp):
        return f"{pad}BinOp({node.op})\n{ast_to_text(node.left, indent+1)}\n{ast_to_text(node.right, indent+1)}"
    elif isinstance(node, UnaryOp):
        return f"{pad}UnaryOp({node.op})\n{ast_to_text(node.operand, indent+1)}"
    elif isinstance(node, Assign):
        return f"{pad}Assign({node.target})\n{ast_to_text(node.value, indent+1)}"
    return f"{pad}UnknownNode"

class ParseError(Exception):
    pass

class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0

    def current(self) -> Token:
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return self.tokens[-1]

    def consume(self, expected_type: str) -> Token:
        tok = self.current()
        if tok.type == expected_type:
            self.pos += 1
            return tok
        raise ParseError(f"Expected {expected_type}, got {tok.type} at line {tok.line} col {tok.column}")

    def parse(self) -> Node:
        # Check if it's an assignment: ID ASSIGN ...
        # We need a small lookahead.
        tok = self.current()
        if tok.type == 'ID' and self.pos + 1 < len(self.tokens):
            next_tok = self.tokens[self.pos + 1]
            if next_tok.type == 'ASSIGN':
                self.consume('ID')
                self.consume('ASSIGN')
                expr = self.parse_expression()
                return Assign(target=tok.value, value=expr)
        
        return self.parse_expression()

    def parse_expression(self) -> Node:
        # Expr -> Term (( '+' | '-' ) Term)*
        node = self.parse_term()
        while self.current().type in ('PLUS', 'MINUS'):
            op_tok = self.current()
            self.pos += 1
            op = '+' if op_tok.type == 'PLUS' else '-'
            right = self.parse_term()
            node = BinOp(op, node, right)
        return node

    def parse_term(self) -> Node:
        # Term -> Unary (( '*' | '/' ) Unary)*
        node = self.parse_unary()
        while self.current().type in ('MUL', 'DIV'):
            op_tok = self.current()
            self.pos += 1
            op = '*' if op_tok.type == 'MUL' else '/'
            right = self.parse_unary()
            node = BinOp(op, node, right)
        return node

    def parse_unary(self) -> Node:
        # Unary -> ( '+' | '-' ) Unary | Power
        if self.current().type in ('PLUS', 'MINUS'):
            op_tok = self.current()
            self.pos += 1
            op = '+' if op_tok.type == 'PLUS' else '-'
            operand = self.parse_unary()
            return UnaryOp(op, operand)
        return self.parse_power()

    def parse_power(self) -> Node:
        # Power -> Atom ( '^' Unary )? # Right associative
        node = self.parse_atom()
        if self.current().type == 'POW':
            self.pos += 1
            right = self.parse_unary() # Using parse_unary handles 2^-3 nicely and implies right-assoc for multiple ^
            node = BinOp('^', node, right)
        return node

    def parse_atom(self) -> Node:
        tok = self.current()
        if tok.type == 'NUM':
            self.pos += 1
            return Num(float(tok.value))
        elif tok.type == 'ID':
            self.pos += 1
            return Var(tok.value)
        elif tok.type == 'LPAREN':
            self.pos += 1
            node = self.parse_expression()
            self.consume('RPAREN')
            return node
        
        raise ParseError(f"Unexpected token {tok.type} ('{tok.value}') at line {tok.line} col {tok.column}")

def parse(text: str) -> Node:
    tokens = lex(text)
    parser = Parser(tokens)
    ast = parser.parse()
    if parser.current().type != 'EOF':
        raise ParseError(f"Unexpected token {parser.current().type} after valid parse")
    return ast
