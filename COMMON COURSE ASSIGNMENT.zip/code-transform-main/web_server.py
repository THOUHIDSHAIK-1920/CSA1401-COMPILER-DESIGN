import json
import http.server
import socketserver
import urllib.parse
from compiler import compile_expression
from backend.report import count_metrics
from frontend.parser import Num, Var, BinOp, UnaryOp, Assign

PORT = 8000

def ast_to_dict(node):
    if isinstance(node, Num):
        return {"type": "Num", "value": node.value}
    elif isinstance(node, Var):
        return {"type": "Var", "name": node.name}
    elif isinstance(node, BinOp):
        return {
            "type": "BinOp",
            "op": node.op,
            "left": ast_to_dict(node.left),
            "right": ast_to_dict(node.right)
        }
    elif isinstance(node, UnaryOp):
        return {
            "type": "UnaryOp",
            "op": node.op,
            "operand": ast_to_dict(node.operand)
        }
    elif isinstance(node, Assign):
        return {
            "type": "Assign",
            "target": node.target,
            "value": ast_to_dict(node.value)
        }
    return {"type": "Unknown"}

class CompilerHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urllib.parse.urlparse(self.path)
        if parsed_path.path == '/' or parsed_path.path == '/index.html':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            with open('web/index.html', 'rb') as f:
                self.wfile.write(f.read())
        elif parsed_path.path.startswith('/static/'):
            try:
                filepath = parsed_path.path.lstrip('/')
                with open(filepath, 'rb') as f:
                    self.send_response(200)
                    if filepath.endswith('.css'):
                        self.send_header('Content-Type', 'text/css')
                    elif filepath.endswith('.js'):
                        self.send_header('Content-Type', 'application/javascript')
                    self.end_headers()
                    self.wfile.write(f.read())
            except FileNotFoundError:
                self.send_error(404, "File Not Found")
        else:
            self.send_error(404, "Not Found")

    def do_POST(self):
        if self.path == '/api/compile':
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            try:
                payload = json.loads(post_data.decode('utf-8'))
                expression = payload.get('expression', '')
                
                res = compile_expression(expression)
                
                m_before = count_metrics(res.quads)
                m_after = count_metrics(res.opt_quads)
                
                def calc_red(b, a):
                    if b == 0: return 0.0
                    return round(((b - a) / b) * 100.0, 1)

                response_data = {
                    "success": True,
                    "expression": expression,
                    "ast_text": res.ast_text,
                    "ast_dict": ast_to_dict(res.ast),
                    "tac": [str(t) for t in res.tac],
                    "quads": [{"op": q.op, "arg1": q.arg1, "arg2": q.arg2 or "", "result": q.result} for q in res.quads],
                    "triples": [{"index": i, "op": t.op, "arg1": t.arg1, "arg2": t.arg2 or ""} for i, t in enumerate(res.triples)],
                    "opt_quads": [{"op": q.op, "arg1": q.arg1, "arg2": q.arg2 or "", "result": q.result} for q in res.opt_quads],
                    "opt_trace": res.opt_trace,
                    "report_text": res.report,
                    "metrics": {
                        "before": m_before,
                        "after": m_after,
                        "reduction": {
                            "instructions": calc_red(m_before['instructions'], m_after['instructions']),
                            "arith_ops": calc_red(m_before['arith_ops'], m_after['arith_ops']),
                            "temps": calc_red(m_before['temps'], m_after['temps'])
                        }
                    }
                }
            except Exception as e:
                response_data = {
                    "success": False,
                    "error": str(e)
                }
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(response_data).encode('utf-8'))
        else:
            self.send_error(404, "Endpoint Not Found")

def run_server():
    server_address = ('', PORT)
    with socketserver.TCPServer(server_address, CompilerHTTPRequestHandler) as httpd:
        print(f"Compiler Web UI running at http://localhost:{PORT}")
        httpd.serve_forever()

if __name__ == "__main__":
    run_server()
